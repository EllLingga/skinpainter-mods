package com.skinpainter.client.render;

import com.mojang.blaze3d.platform.NativeImage;
import com.skinpainter.SkinPainterMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.DynamicTexture;
import net.minecraft.util.Identifier;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class SkinTextureManager {
    private final Map<UUID, NativeImage>    skinImages  = new HashMap<>();
    private final Map<UUID, DynamicTexture> dynTextures = new HashMap<>();
    private final Map<UUID, Identifier>     textureIds  = new HashMap<>();

    public void paintBrush(UUID uuid, int u, int v, int radius, int argb) {
        NativeImage img = getOrCreateImage(uuid);
        int r2 = radius * radius;
        for (int du = -radius; du <= radius; du++) {
            for (int dv = -radius; dv <= radius; dv++) {
                if (du*du+dv*dv <= r2) {
                    int pu=u+du, pv=v+dv;
                    if (pu>=0&&pu<64&&pv>=0&&pv<64) img.setColor(pu,pv,argbToAbgr(argb));
                }
            }
        }
        uploadTexture(uuid);
    }

    public Identifier getCustomTextureId(UUID uuid) { return textureIds.get(uuid); }
    public boolean hasCustomTexture(UUID uuid) { return textureIds.containsKey(uuid); }

    public void loadFromBytes(UUID uuid, byte[] pngBytes) {
        try {
            NativeImage img = NativeImage.read(new ByteArrayInputStream(pngBytes));
            NativeImage old = skinImages.put(uuid, img);
            if (old != null) old.close();
            uploadTexture(uuid);
        } catch (IOException e) {
            SkinPainterMod.LOGGER.error("[SkinPainter] Gagal load skin", e);
        }
    }

    public byte[] exportToBytes(UUID uuid) {
        NativeImage img = skinImages.get(uuid);
        if (img == null) return null;
        try { return img.getBytes(); }
        catch (IOException e) { SkinPainterMod.LOGGER.error("[SkinPainter] Gagal export skin", e); return null; }
    }

    public NativeImage getOrCreateImage(UUID uuid) {
        return skinImages.computeIfAbsent(uuid, id -> new NativeImage(64, 64, true));
    }

    private void uploadTexture(UUID uuid) {
        NativeImage img = skinImages.get(uuid);
        if (img == null) return;
        DynamicTexture tex = dynTextures.get(uuid);
        if (tex == null) {
            DynamicTexture newTex = new DynamicTexture(img);
            Identifier id = new Identifier(SkinPainterMod.MOD_ID, "skin_"+uuid.toString().replace("-",""));
            MinecraftClient.getInstance().getTextureManager().registerTexture(id, newTex);
            dynTextures.put(uuid, newTex);
            textureIds.put(uuid, id);
        } else { tex.upload(); }
    }

    private static int argbToAbgr(int argb) {
        int a=(argb>>24)&0xFF, r=(argb>>16)&0xFF, g=(argb>>8)&0xFF, b=argb&0xFF;
        return (a<<24)|(b<<16)|(g<<8)|r;
    }
}
