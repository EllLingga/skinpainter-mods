package com.skinpainter.client.painting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

public class ModelRayCaster {

    public static class BodyPart {
        public final String name;
        public final float minX, minY, minZ, maxX, maxY, maxZ;
        public final int[][] faceUV;
        public BodyPart(String name, float minX, float minY, float minZ,
                        float maxX, float maxY, float maxZ, int[][] faceUV) {
            this.name = name;
            this.minX = minX/16f; this.minY = minY/16f; this.minZ = minZ/16f;
            this.maxX = maxX/16f; this.maxY = maxY/16f; this.maxZ = maxZ/16f;
            this.faceUV = faceUV;
        }
    }

    public static final BodyPart[] BODY_PARTS = {
        new BodyPart("Head",     -4,24,-4,  4,32, 4, new int[][]{{8,8,16,16},{24,8,32,16},{0,8,8,16},{16,8,24,16},{8,0,16,8},{16,0,24,8}}),
        new BodyPart("Body",     -4,12,-2,  4,24, 2, new int[][]{{20,20,28,32},{32,20,40,32},{16,20,20,32},{28,20,32,32},{20,16,28,20},{28,16,36,20}}),
        new BodyPart("RightArm", -8,12,-2, -4,24, 2, new int[][]{{44,20,48,32},{52,20,56,32},{40,20,44,32},{48,20,52,32},{44,16,48,20},{48,16,52,20}}),
        new BodyPart("LeftArm",   4,12,-2,  8,24, 2, new int[][]{{36,52,40,64},{44,52,48,64},{32,52,36,64},{40,52,44,64},{36,48,40,52},{40,48,44,52}}),
        new BodyPart("RightLeg", -4, 0,-2,  0,12, 2, new int[][]{{ 4,20, 8,32},{12,20,16,32},{ 0,20, 4,32},{ 8,20,12,32},{ 4,16, 8,20},{ 8,16,12,20}}),
        new BodyPart("LeftLeg",   0, 0,-2,  4,12, 2, new int[][]{{20,52,24,64},{28,52,32,64},{16,52,20,64},{24,52,28,64},{20,48,24,52},{24,48,28,52}}),
    };

    public static class HitResult {
        public final BodyPart part;
        public final int u, v;
        public final double distance;
        public HitResult(BodyPart part, int u, int v, double distance) {
            this.part=part; this.u=u; this.v=v; this.distance=distance;
        }
    }

    public static HitResult cast(double mouseX, double mouseY, PlayerEntity player) {
        MinecraftClient client = MinecraftClient.getInstance();
        Camera camera = client.gameRenderer.getCamera();
        int screenW = client.getWindow().getScaledWidth();
        int screenH = client.getWindow().getScaledHeight();

        double fovDeg = client.options.getFov().getValue();
        double tanHalfFovY = Math.tan(Math.toRadians(fovDeg / 2.0));
        double aspect = (double) screenW / screenH;
        double ndcX = 2.0 * mouseX / screenW - 1.0;
        double ndcY = -(2.0 * mouseY / screenH - 1.0);
        double rayDirCamX = ndcX * tanHalfFovY * aspect;
        double rayDirCamY = ndcY * tanHalfFovY;
        double rayDirCamZ = -1.0;

        float pitchRad = (float) Math.toRadians(camera.getPitch());
        float yawRad   = (float) Math.toRadians(camera.getYaw());
        double cosPitch=Math.cos(pitchRad), sinPitch=Math.sin(pitchRad);
        double cosYaw=Math.cos(yawRad),     sinYaw=Math.sin(yawRad);

        double rightX=cosYaw, rightY=0, rightZ=sinYaw;
        double upX=-sinYaw*sinPitch, upY=cosPitch, upZ=cosYaw*sinPitch;
        double fwdX=-sinYaw*cosPitch, fwdY=-sinPitch, fwdZ=cosYaw*cosPitch;

        double worldDirX = rayDirCamX*rightX + rayDirCamY*upX + rayDirCamZ*(-fwdX);
        double worldDirY = rayDirCamX*rightY + rayDirCamY*upY + rayDirCamZ*(-fwdY);
        double worldDirZ = rayDirCamX*rightZ + rayDirCamY*upZ + rayDirCamZ*(-fwdZ);
        double len = Math.sqrt(worldDirX*worldDirX+worldDirY*worldDirY+worldDirZ*worldDirZ);
        worldDirX/=len; worldDirY/=len; worldDirZ/=len;

        Vec3d rayOrigin = camera.getPos();
        Vec3d playerPos = player.getPos();
        double lox=rayOrigin.x-playerPos.x, loy=rayOrigin.y-playerPos.y, loz=rayOrigin.z-playerPos.z;

        float pyRad = (float) Math.toRadians(player.getBodyYaw()+180f);
        double cpY=Math.cos(pyRad), spY=Math.sin(pyRad);
        double ox = lox*cpY - loz*spY, oy=loy, oz=lox*spY+loz*cpY;
        double dx = worldDirX*cpY - worldDirZ*spY, dy=worldDirY, dz=worldDirX*spY+worldDirZ*cpY;

        HitResult closest = null;
        for (BodyPart part : BODY_PARTS) {
            double t = rayAABB(ox,oy,oz,dx,dy,dz,part.minX,part.minY,part.minZ,part.maxX,part.maxY,part.maxZ);
            if (t < 0) continue;
            if (closest != null && t >= closest.distance) continue;
            double hx=ox+dx*t, hy=oy+dy*t, hz=oz+dz*t;
            int[] uv = hitToUV(hx,hy,hz,part,dx,dy,dz);
            if (uv != null) closest = new HitResult(part, uv[0], uv[1], t);
        }
        return closest;
    }

    private static double rayAABB(double ox,double oy,double oz,double dx,double dy,double dz,
                                   float minX,float minY,float minZ,float maxX,float maxY,float maxZ) {
        double tMin=Double.NEGATIVE_INFINITY, tMax=Double.POSITIVE_INFINITY;
        if(Math.abs(dx)>1e-9){double t1=(minX-ox)/dx,t2=(maxX-ox)/dx;tMin=Math.max(tMin,Math.min(t1,t2));tMax=Math.min(tMax,Math.max(t1,t2));}
        else if(ox<minX||ox>maxX)return -1;
        if(Math.abs(dy)>1e-9){double t1=(minY-oy)/dy,t2=(maxY-oy)/dy;tMin=Math.max(tMin,Math.min(t1,t2));tMax=Math.min(tMax,Math.max(t1,t2));}
        else if(oy<minY||oy>maxY)return -1;
        if(Math.abs(dz)>1e-9){double t1=(minZ-oz)/dz,t2=(maxZ-oz)/dz;tMin=Math.max(tMin,Math.min(t1,t2));tMax=Math.min(tMax,Math.max(t1,t2));}
        else if(oz<minZ||oz>maxZ)return -1;
        if(tMax<tMin||tMax<0)return -1;
        return tMin<0?tMax:tMin;
    }

    private static int[] hitToUV(double hx,double hy,double hz,BodyPart p,double dx,double dy,double dz) {
        double eps=1e-4;
        int fi; double lu,lv;
        if(Math.abs(hz-p.maxZ)<eps&&dz<0){fi=0;lu=(hx-p.minX)/(p.maxX-p.minX);lv=1-(hy-p.minY)/(p.maxY-p.minY);}
        else if(Math.abs(hz-p.minZ)<eps&&dz>0){fi=1;lu=1-(hx-p.minX)/(p.maxX-p.minX);lv=1-(hy-p.minY)/(p.maxY-p.minY);}
        else if(Math.abs(hx-p.maxX)<eps&&dx<0){fi=2;lu=1-(hz-p.minZ)/(p.maxZ-p.minZ);lv=1-(hy-p.minY)/(p.maxY-p.minY);}
        else if(Math.abs(hx-p.minX)<eps&&dx>0){fi=3;lu=(hz-p.minZ)/(p.maxZ-p.minZ);lv=1-(hy-p.minY)/(p.maxY-p.minY);}
        else if(Math.abs(hy-p.maxY)<eps&&dy<0){fi=4;lu=(hx-p.minX)/(p.maxX-p.minX);lv=(hz-p.minZ)/(p.maxZ-p.minZ);}
        else if(Math.abs(hy-p.minY)<eps&&dy>0){fi=5;lu=(hx-p.minX)/(p.maxX-p.minX);lv=1-(hz-p.minZ)/(p.maxZ-p.minZ);}
        else return null;
        int[]r=p.faceUV[fi];
        int u=r[0]+(int)(lu*(r[2]-r[0])), v=r[1]+(int)(lv*(r[3]-r[1]));
        return new int[]{Math.max(r[0],Math.min(r[2]-1,u)), Math.max(r[1],Math.min(r[3]-1,v))};
    }
}
