package com.skinpainter.client.painting;

import com.skinpainter.SkinPainterMod;
import com.skinpainter.client.render.SkinTextureManager;
import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;

import java.awt.*;
import java.util.UUID;

/**
 * Core painting controller.
 *
 * Mode yang tersedia:
 *  PAINT  → cat skin dengan warna yang dipilih
 *  PICKER → ambil warna dari blok yang dilihat
 *  ERASER → hapus cat (pixel jadi transparan, skin asli terlihat)   ← FITUR BARU #1
 *
 * Undo/Redo dikelola lewat UndoRedoManager                         ← FITUR BARU #2
 */
public class SkinPainter {

    private final SkinTextureManager textureManager;
    private UndoRedoManager undoRedoManager;

    private PaintMode mode   = PaintMode.PAINT;
    private float  hue       = 0f;
    private float  saturation = 1f;
    private float  brightness = 1f;
    private int    brushRadius = 1;
    private int    currentArgb = 0xFF_FF5500; // orange default

    // Eraser warna target (transparan)
    private static final int ERASER_COLOR = 0x00_000000;

    public SkinPainter(SkinTextureManager mgr) {
        this.textureManager = mgr;
    }

    /** Harus dipanggil setelah player UUID diketahui (setelah masuk mode). */
    public void initForPlayer(UUID uuid) {
        undoRedoManager = new UndoRedoManager(textureManager, uuid);
    }

    // ── Paint / Pick / Erase actions ─────────────────────────────

    /**
     * Dipanggil saat mouse LEFT ditekan di dunia (bukan di HUD).
     * Membuat snapshot untuk undo, lalu memulai aksi.
     */
    public void onStrokeBegin(double mouseX, double mouseY) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;

        if (mode == PaintMode.PICKER) {
            doPickColor(client);
            return;
        }

        // Snapshot SEBELUM stroke untuk undo
        if (undoRedoManager != null) undoRedoManager.beginStroke();

        doStroke(mouseX, mouseY, client.player);
    }

    /**
     * Dipanggil terus-menerus saat mouse kiri ditahan (drag stroke).
     */
    public void onStrokeDrag(double mouseX, double mouseY) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;
        if (mode == PaintMode.PICKER) return;
        doStroke(mouseX, mouseY, client.player);
    }

    /**
     * Dipanggil saat mouse LEFT dilepas — commit snapshot ke undo stack.
     */
    public void onStrokeEnd() {
        if (undoRedoManager != null) undoRedoManager.commitStroke();
    }

    private void doStroke(double mouseX, double mouseY, PlayerEntity player) {
        ModelRayCaster.HitResult hit = ModelRayCaster.cast(mouseX, mouseY, player);
        if (hit == null) return;

        SkinPainterMod.LOGGER.debug("[SkinPainter] {} hit {} UV({},{})",
                mode, hit.part.name, hit.u, hit.v);

        int color = (mode == PaintMode.ERASER) ? ERASER_COLOR : currentArgb;
        textureManager.paintBrush(player.getUuid(), hit.u, hit.v, brushRadius, color);
    }

    private void doPickColor(MinecraftClient client) {
        if (client.crosshairTarget == null || client.world == null) return;
        if (client.crosshairTarget.getType() != HitResult.Type.BLOCK) return;

        BlockHitResult blockHit = (BlockHitResult) client.crosshairTarget;
        BlockPos pos = blockHit.getBlockPos();
        Block block = client.world.getBlockState(pos).getBlock();

        int mapColor = block.getDefaultMapColor().color;
        int r = (mapColor >> 16) & 0xFF;
        int g = (mapColor >> 8)  & 0xFF;
        int b =  mapColor        & 0xFF;

        setCurrentColorRGB(r, g, b);
        SkinPainterMod.LOGGER.info("[SkinPainter] Picked #{}", String.format("%06X", mapColor & 0xFFFFFF));
        mode = PaintMode.PAINT; // Auto-switch kembali ke paint
    }

    // ── Undo / Redo ──────────────────────────────────────────────

    public boolean undo() {
        if (undoRedoManager == null) return false;
        return undoRedoManager.undo();
    }

    public boolean redo() {
        if (undoRedoManager == null) return false;
        return undoRedoManager.redo();
    }

    public boolean canUndo() { return undoRedoManager != null && undoRedoManager.canUndo(); }
    public boolean canRedo() { return undoRedoManager != null && undoRedoManager.canRedo(); }
    public int undoCount()   { return undoRedoManager != null ? undoRedoManager.undoCount() : 0; }
    public int redoCount()   { return undoRedoManager != null ? undoRedoManager.redoCount() : 0; }

    public void clearHistory() {
        if (undoRedoManager != null) undoRedoManager.clear();
    }

    // ── Getters / Setters ────────────────────────────────────────

    public PaintMode getMode()        { return mode; }
    public void setMode(PaintMode m)  { this.mode = m; }

    public int  getCurrentArgb()      { return currentArgb; }
    public int  getCurrentRGB()       { return currentArgb & 0x00_FFFFFF; }

    public float getHue()             { return hue; }
    public float getSaturation()      { return saturation; }
    public float getBrightness()      { return brightness; }

    public int  getBrushRadius()                   { return brushRadius; }
    public void setBrushRadius(int r)              { this.brushRadius = Math.max(1, Math.min(8, r)); }

    public void setHSB(float h, float s, float b) {
        this.hue = h; this.saturation = s; this.brightness = b;
        Color c = Color.getHSBColor(h, s, b);
        currentArgb = 0xFF_000000 | (c.getRed() << 16) | (c.getGreen() << 8) | c.getBlue();
    }

    public void setCurrentColorRGB(int r, int g, int b) {
        float[] hsb = Color.RGBtoHSB(r, g, b, null);
        setHSB(hsb[0], hsb[1], hsb[2]);
    }
}
