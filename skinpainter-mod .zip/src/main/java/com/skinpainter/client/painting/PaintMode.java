package com.skinpainter.client.painting;

public enum PaintMode {
    /** Paint with selected color onto the skin */
    PAINT,

    /** Pick color from a block you look at */
    PICKER,

    /** Erase painted pixels back to transparent (reveals original skin) */
    ERASER
}
