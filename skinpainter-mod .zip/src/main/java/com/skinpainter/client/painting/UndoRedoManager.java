package com.skinpainter.client.painting;

import com.mojang.blaze3d.platform.NativeImage;
import com.skinpainter.SkinPainterMod;
import com.skinpainter.client.render.SkinTextureManager;

import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.UUID;

/**
 * FITUR BARU #1: Undo / Redo
 * ─────────────────────────────────────────────────────────────────
 * Menyimpan snapshot (salinan) dari skin image setiap kali stroke
 * selesai (mouse release). Mendukung hingga MAX_HISTORY langkah.
 *
 * Ctrl+Z  → undo (kembali ke state sebelumnya)
 * Ctrl+Y  → redo (maju ke state yang di-undo)
 */
public class UndoRedoManager {

    private static final int MAX_HISTORY = 20;

    private final SkinTextureManager textureManager;
    private final UUID playerUuid;

    /** Stack untuk undo — setiap item adalah PNG bytes snapshot */
    private final Deque<byte[]> undoStack = new ArrayDeque<>();
    /** Stack untuk redo */
    private final Deque<byte[]> redoStack = new ArrayDeque<>();

    /** Snapshot dari sebelum stroke dimulai (pending commit) */
    private byte[] pendingSnapshot = null;

    public UndoRedoManager(SkinTextureManager mgr, UUID uuid) {
        this.textureManager = mgr;
        this.playerUuid     = uuid;
    }

    // ── Lifecycle ────────────────────────────────────────────────

    /**
     * Panggil SEBELUM stroke dimulai (mouse press) untuk snapshot state saat ini.
     */
    public void beginStroke() {
        pendingSnapshot = captureSnapshot();
    }

    /**
     * Panggil SETELAH stroke selesai (mouse release) untuk commit snapshot ke undo stack.
     */
    public void commitStroke() {
        if (pendingSnapshot == null) return;
        pushUndo(pendingSnapshot);
        pendingSnapshot = null;
        redoStack.clear(); // Setiap aksi baru menghapus redo history
    }

    /**
     * Panggil jika stroke dibatalkan tanpa perubahan.
     */
    public void cancelStroke() {
        pendingSnapshot = null;
    }

    // ── Undo / Redo ──────────────────────────────────────────────

    /**
     * Batalkan aksi terakhir (Ctrl+Z).
     * @return true jika berhasil
     */
    public boolean undo() {
        if (undoStack.isEmpty()) {
            SkinPainterMod.LOGGER.info("[SkinPainter] Tidak ada yang bisa di-undo.");
            return false;
        }

        // Simpan state sekarang ke redo stack
        byte[] current = captureSnapshot();
        if (current != null) redoStack.push(current);

        // Restore state sebelumnya
        byte[] prev = undoStack.pop();
        restoreSnapshot(prev);

        SkinPainterMod.LOGGER.info("[SkinPainter] Undo! ({} langkah tersisa)", undoStack.size());
        return true;
    }

    /**
     * Ulangi aksi yang di-undo (Ctrl+Y).
     * @return true jika berhasil
     */
    public boolean redo() {
        if (redoStack.isEmpty()) {
            SkinPainterMod.LOGGER.info("[SkinPainter] Tidak ada yang bisa di-redo.");
            return false;
        }

        // Simpan state sekarang ke undo stack
        byte[] current = captureSnapshot();
        if (current != null) pushUndo(current);

        // Restore state redo
        byte[] next = redoStack.pop();
        restoreSnapshot(next);

        SkinPainterMod.LOGGER.info("[SkinPainter] Redo! ({} langkah redo tersisa)", redoStack.size());
        return true;
    }

    public boolean canUndo() { return !undoStack.isEmpty(); }
    public boolean canRedo() { return !redoStack.isEmpty(); }
    public int     undoCount() { return undoStack.size(); }
    public int     redoCount() { return redoStack.size(); }

    /** Reset semua history (misalnya saat keluar mode edit). */
    public void clear() {
        undoStack.clear();
        redoStack.clear();
        pendingSnapshot = null;
    }

    // ── Internal ─────────────────────────────────────────────────

    private void pushUndo(byte[] snapshot) {
        undoStack.push(snapshot);
        // Buang history tertua jika melebihi batas
        while (undoStack.size() > MAX_HISTORY) {
            ((ArrayDeque<byte[]>) undoStack).removeLast();
        }
    }

    private byte[] captureSnapshot() {
        try {
            return textureManager.exportToBytes(playerUuid);
        } catch (Exception e) {
            SkinPainterMod.LOGGER.error("[SkinPainter] Gagal snapshot untuk undo", e);
            return null;
        }
    }

    private void restoreSnapshot(byte[] data) {
        if (data == null) return;
        textureManager.loadFromBytes(playerUuid, data);
    }
}
