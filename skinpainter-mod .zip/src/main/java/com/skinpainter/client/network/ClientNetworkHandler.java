package com.skinpainter.client.network;

import com.skinpainter.SkinPainterMod;
import com.skinpainter.client.render.SkinTextureManager;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.network.PacketByteBuf;
import java.util.UUID;

public class ClientNetworkHandler {
    private static SkinTextureManager textureManager;

    public static void register(SkinTextureManager mgr) {
        textureManager = mgr;
        ClientPlayNetworking.registerGlobalReceiver(SkinPainterMod.SKIN_UPDATE_S2C,
                (client, handler, buf, responseSender) -> {
                    UUID playerUuid = buf.readUuid();
                    byte[] skinData = buf.readByteArray();
                    client.execute(() -> textureManager.loadFromBytes(playerUuid, skinData));
                });
    }

    public static void sendSkinUpdate(UUID playerUuid) {
        byte[] data = textureManager.exportToBytes(playerUuid);
        if (data == null) return;
        if (data.length > 1_000_000) {
            SkinPainterMod.LOGGER.warn("[SkinPainter] Skin data terlalu besar: {} bytes", data.length);
            return;
        }
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeByteArray(data);
        ClientPlayNetworking.send(SkinPainterMod.SKIN_UPDATE_C2S, buf);
    }
}
