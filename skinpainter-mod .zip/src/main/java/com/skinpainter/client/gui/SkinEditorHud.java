package com.skinpainter.client.gui;

import com.skinpainter.client.SkinPainterClient;
import com.skinpainter.client.painting.PaintMode;
import com.skinpainter.client.painting.SkinPainter;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/**
 * HUD overlay di kiri bawah saat mode edit aktif.
 *
 * Layout:
 *  ┌────────────────────────────────┐
 *  │ ✦ Skin Painter ✦               │
 *  │  [Color Wheel]                 │
 *  │  [Brightness Slider]           │
 *  │  [Color Swatch]  #RRGGBB      │
 *  │  [✏ Paint] [🎯 Picker] [✦ Erase]│  ← Eraser Baru
 *  │  Brush: ○ - +                  │
 *  │  [↩ Undo 5] [↪ Redo 2]        │  ← Undo/Redo Baru
 *  │  [ESC] Keluar  [RMB] Kamera    │
 *  └────────────────────────────────┘
 */
public class SkinEditorHud {

    private final SkinPainter     painter;
    private final ColorWheelWidget colorWheel;

    private int panelX, panelY, panelW, panelH;

    // Button areas (set each frame)
    private int btnPaintX,  btnPickerX, btnEraserX, btnModeY;
    private int btnBrushMinusX, btnBrushPlusX, btnBrushY;
    private int btnUndoX,  btnRedoX,  btnUndoRedoY;

    private static final int WHEEL_RADIUS   = 65;
    private static final int PAD_LEFT       = 10;
    private static final int PAD_BOTTOM     = 10;
    private static final int INNER          = 8;
    private static final int BTN_H          = 18;
    private static final int BTN_W_MODE     = 70;  // mode buttons (3 total)
    private static final int BTN_W_UNDOREDO = 82;

    public SkinEditorHud(SkinPainter p) {
        this.painter    = p;
        this.colorWheel = new ColorWheelWidget(0, 0, WHEEL_RADIUS, p);
    }

    // ── Rendering ────────────────────────────────────────────────

    public void render(DrawContext ctx, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        int screenH = mc.getWindow().getScaledHeight();

        int wheelDiam  = WHEEL_RADIUS * 2;
        int wheelTotal = colorWheel.getTotalHeight();

        panelW = wheelDiam + INNER * 2 + 10;
        panelH = INNER + 14 + INNER          // title
               + wheelTotal + INNER           // wheel
               + BTN_H + INNER               // mode row
               + BTN_H + INNER               // brush row
               + BTN_H + INNER               // undo/redo row
               + 10 + INNER;                 // hint

        panelX = PAD_LEFT;
        panelY = screenH - panelH - PAD_BOTTOM;

        // ── Background ──────────────────────────────────────────
        ctx.fill(panelX - 3, panelY - 3,
                 panelX + panelW + 3, panelY + panelH + 3, 0xCC0A0A12);
        // Border top/bottom
        ctx.fill(panelX - 3, panelY - 3, panelX + panelW + 3, panelY - 2, 0xFF4488BB);
        ctx.fill(panelX - 3, panelY + panelH + 2, panelX + panelW + 3, panelY + panelH + 3, 0xFF4488BB);
        // Border left/right
        ctx.fill(panelX - 3, panelY - 3, panelX - 2, panelY + panelH + 3, 0xFF4488BB);
        ctx.fill(panelX + panelW + 2, panelY - 3, panelX + panelW + 3, panelY + panelH + 3, 0xFF4488BB);

        int cur = panelY + INNER;

        // ── Title ───────────────────────────────────────────────
        ctx.drawText(mc.textRenderer,
                Text.literal("§b✦ §eSkin Painter §b✦"),
                panelX + INNER, cur + 2, 0xFFFFFF, true);
        cur += 14 + INNER;

        // ── Color Wheel ─────────────────────────────────────────
        colorWheel.setPosition(panelX + INNER, cur);
        colorWheel.render(ctx, delta);
        cur += wheelTotal + INNER;

        // ── Mode Buttons (Paint / Picker / Eraser) ──────────────
        btnModeY    = cur;
        btnPaintX   = panelX + INNER;
        btnPickerX  = btnPaintX  + BTN_W_MODE + 3;
        btnEraserX  = btnPickerX + BTN_W_MODE + 3;

        drawModeBtn(ctx, mc, btnPaintX,  cur, BTN_W_MODE, BTN_H,
                "§f✏ Paint",   painter.getMode() == PaintMode.PAINT,   0xFF1A5C1A);
        drawModeBtn(ctx, mc, btnPickerX, cur, BTN_W_MODE, BTN_H,
                "§f🎯 Pick",   painter.getMode() == PaintMode.PICKER,  0xFF1A1A5C);
        // ERASER button — merah gelap saat aktif
        drawModeBtn(ctx, mc, btnEraserX, cur, BTN_W_MODE, BTN_H,
                "§f✦ Erase",  painter.getMode() == PaintMode.ERASER,  0xFF5C1A1A);
        cur += BTN_H + INNER;

        // ── Brush Size ──────────────────────────────────────────
        btnBrushY      = cur;
        btnBrushMinusX = panelX + INNER;
        btnBrushPlusX  = btnBrushMinusX + 20;

        drawSmallBtn(ctx, mc, btnBrushMinusX, cur, 18, BTN_H, "§f-");
        drawSmallBtn(ctx, mc, btnBrushPlusX,  cur, 18, BTN_H, "§f+");

        // Brush radius visual dots
        int dotStartX = btnBrushPlusX + 22;
        int maxDots   = Math.min(painter.getBrushRadius(), 8);
        for (int i = 0; i < maxDots; i++) {
            ctx.fill(dotStartX + i * 9, cur + 7, dotStartX + i * 9 + 7, cur + 15, 0xFF_AADDFF);
        }
        ctx.drawText(mc.textRenderer,
                Text.literal("§7 r=" + painter.getBrushRadius() + "px"),
                dotStartX + maxDots * 9 + 2, cur + 5, 0xAAAAAA, false);
        cur += BTN_H + INNER;

        // ── Undo / Redo row ─────────────────────────────────────
        btnUndoRedoY = cur;
        btnUndoX     = panelX + INNER;
        btnRedoX     = btnUndoX + BTN_W_UNDOREDO + 4;

        boolean canUndo = painter.canUndo();
        boolean canRedo = painter.canRedo();

        drawActionBtn(ctx, mc, btnUndoX, cur, BTN_W_UNDOREDO, BTN_H,
                "§f↩ Undo §7(" + painter.undoCount() + ")", canUndo, 0xFF2A2020);
        drawActionBtn(ctx, mc, btnRedoX, cur, BTN_W_UNDOREDO, BTN_H,
                "§f↪ Redo §7(" + painter.redoCount() + ")", canRedo, 0xFF202A20);
        cur += BTN_H + INNER;

        // ── Hint ────────────────────────────────────────────────
        ctx.drawText(mc.textRenderer,
                Text.literal("§7[ESC] Keluar  §8|§7 [RMB] Putar kamera"),
                panelX + INNER, cur, 0x777777, false);
    }

    // ── Button drawing helpers ────────────────────────────────────

    private void drawModeBtn(DrawContext ctx, MinecraftClient mc,
                              int x, int y, int w, int h,
                              String label, boolean active, int activeBg) {
        int border = active ? 0xFF88BBEE : 0xFF444444;
        int bg     = active ? activeBg   : 0xFF1E1E1E;
        ctx.fill(x, y, x + w, y + h, border);
        ctx.fill(x + 1, y + 1, x + w - 1, y + h - 1, bg);
        ctx.drawText(mc.textRenderer, Text.literal(label), x + 4, y + 5, 0xFFFFFF, false);
    }

    private void drawSmallBtn(DrawContext ctx, MinecraftClient mc,
                               int x, int y, int w, int h, String label) {
        ctx.fill(x, y, x + w, y + h, 0xFF555555);
        ctx.fill(x + 1, y + 1, x + w - 1, y + h - 1, 0xFF2A2A2A);
        ctx.drawText(mc.textRenderer, Text.literal(label), x + 5, y + 5, 0xFFFFFF, false);
    }

    private void drawActionBtn(DrawContext ctx, MinecraftClient mc,
                                int x, int y, int w, int h,
                                String label, boolean enabled, int enabledBg) {
        int border = enabled ? 0xFF888888 : 0xFF333333;
        int bg     = enabled ? enabledBg  : 0xFF111111;
        int textCol = enabled ? 0xFFFFFF : 0xFF666666;
        ctx.fill(x, y, x + w, y + h, border);
        ctx.fill(x + 1, y + 1, x + w - 1, y + h - 1, bg);
        ctx.drawText(mc.textRenderer, Text.literal(label), x + 5, y + 5, textCol, false);
    }

    // ── Input ────────────────────────────────────────────────────

    public boolean onMouseClick(double mx, double my, int button) {
        if (!isMouseOverPanel(mx, my)) return false;

        // Color wheel first
        if (colorWheel.onMouseClick(mx, my, button)) return true;

        if (button != 0) return true;

        // Mode buttons
        if (inBtn(mx, my, btnPaintX,  btnModeY, BTN_W_MODE, BTN_H)) {
            painter.setMode(PaintMode.PAINT);  return true;
        }
        if (inBtn(mx, my, btnPickerX, btnModeY, BTN_W_MODE, BTN_H)) {
            painter.setMode(PaintMode.PICKER); return true;
        }
        if (inBtn(mx, my, btnEraserX, btnModeY, BTN_W_MODE, BTN_H)) {
            painter.setMode(PaintMode.ERASER); return true;
        }

        // Brush size
        if (inBtn(mx, my, btnBrushMinusX, btnBrushY, 18, BTN_H)) {
            painter.setBrushRadius(painter.getBrushRadius() - 1); return true;
        }
        if (inBtn(mx, my, btnBrushPlusX, btnBrushY, 18, BTN_H)) {
            painter.setBrushRadius(painter.getBrushRadius() + 1); return true;
        }

        // Undo / Redo buttons
        if (inBtn(mx, my, btnUndoX, btnUndoRedoY, BTN_W_UNDOREDO, BTN_H)) {
            painter.undo(); return true;
        }
        if (inBtn(mx, my, btnRedoX, btnUndoRedoY, BTN_W_UNDOREDO, BTN_H)) {
            painter.redo(); return true;
        }

        return true; // absorb all panel clicks
    }

    public void onMouseRelease(double mx, double my, int button) {
        colorWheel.onMouseRelease(button);
    }

    public void onMouseMove(double mx, double my) {
        colorWheel.onMouseMove(mx, my);
    }

    public boolean isMouseOverPanel(double mx, double my) {
        return mx >= panelX - 3 && mx <= panelX + panelW + 3 &&
               my >= panelY - 3 && my <= panelY + panelH + 3;
    }

    private boolean inBtn(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }
}
