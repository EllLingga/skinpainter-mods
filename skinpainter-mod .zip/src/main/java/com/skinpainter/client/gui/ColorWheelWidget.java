package com.skinpainter.client.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import com.skinpainter.client.painting.SkinPainter;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.*;
import net.minecraft.text.Text;
import java.awt.*;

public class ColorWheelWidget {
    private int x, y;
    private final int radius;
    private final SkinPainter painter;
    private boolean draggingWheel=false, draggingSlider=false;
    private float hue=0f, saturation=1f, brightness=1f;
    private static final int SLIDER_H=12, SLIDER_M=8;

    public ColorWheelWidget(int x, int y, int radius, SkinPainter painter) {
        this.x=x; this.y=y; this.radius=radius; this.painter=painter;
    }
    public void setPosition(int x, int y) { this.x=x; this.y=y; }

    private void syncFromPainter() {
        hue=painter.getHue(); saturation=painter.getSaturation(); brightness=painter.getBrightness();
    }

    public void render(DrawContext ctx, float delta) {
        syncFromPainter();
        int cx=x+radius, cy=y+radius, diam=radius*2;
        drawColorWheel(cx,cy);
        double a=hue*Math.PI*2;
        int dotX=cx+(int)(Math.cos(a)*saturation*radius), dotY=cy+(int)(Math.sin(a)*saturation*radius);
        ctx.fill(dotX-3,dotY-3,dotX+3,dotY+3,0xFFFFFFFF);
        ctx.fill(dotX-2,dotY-2,dotX+2,dotY+2,0xFF000000);
        int slY=y+diam+SLIDER_M;
        drawBrightnessSlider(slY, diam);
        int hX=x+(int)(brightness*(diam-4))+2;
        ctx.fill(hX-3,slY-2,hX+3,slY+SLIDER_H+2,0xFFFFFFFF);
        ctx.fill(hX-2,slY-1,hX+2,slY+SLIDER_H+1,0xFF555555);
        int swY=slY+SLIDER_H+6;
        int swatch=0xFF000000|painter.getCurrentRGB();
        ctx.fill(x,swY,x+diam,swY+14,0xFF000000);
        ctx.fill(x+1,swY+1,x+diam-1,swY+13,swatch);
        ctx.drawText(MinecraftClient.getInstance().textRenderer,
            Text.literal(String.format("§7#%06X",painter.getCurrentRGB())),
            x+diam+6,swY+3,0xFFFFFF,false);
    }

    private void drawColorWheel(int cx,int cy) {
        Tessellator t=Tessellator.getInstance(); BufferBuilder b=t.getBuffer();
        RenderSystem.enableBlend(); RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);
        b.begin(VertexFormat.DrawMode.TRIANGLE_FAN,VertexFormats.POSITION_COLOR);
        b.vertex(cx,cy,0).color(255,255,255,255).next();
        int segs=72;
        for(int i=0;i<=segs;i++){
            float angle=(float)(i*Math.PI*2.0/segs), h=angle/(float)(Math.PI*2.0);
            Color c=Color.getHSBColor(h,1.0f,brightness);
            b.vertex(cx+(float)Math.cos(angle)*radius,cy+(float)Math.sin(angle)*radius,0)
             .color(c.getRed(),c.getGreen(),c.getBlue(),255).next();
        }
        t.draw(); RenderSystem.disableBlend();
    }

    private void drawBrightnessSlider(int slY,int w) {
        Tessellator t=Tessellator.getInstance(); BufferBuilder b=t.getBuffer();
        RenderSystem.enableBlend(); RenderSystem.setShader(GameRenderer::getPositionColorProgram);
        Color fc=Color.getHSBColor(hue,saturation,1.0f);
        b.begin(VertexFormat.DrawMode.QUADS,VertexFormats.POSITION_COLOR);
        b.vertex(x,slY+SLIDER_H,0).color(0,0,0,255).next();
        b.vertex(x,slY,0).color(0,0,0,255).next();
        b.vertex(x+w,slY,0).color(fc.getRed(),fc.getGreen(),fc.getBlue(),255).next();
        b.vertex(x+w,slY+SLIDER_H,0).color(fc.getRed(),fc.getGreen(),fc.getBlue(),255).next();
        t.draw(); RenderSystem.disableBlend();
    }

    public boolean onMouseClick(double mx,double my,int button) {
        if(button!=0)return false;
        int diam=radius*2; int slY=y+diam+SLIDER_M;
        if(mx>=x&&mx<=x+diam&&my>=slY-2&&my<=slY+SLIDER_H+2){draggingSlider=true;updateBrightness(mx);return true;}
        double dx=mx-(x+radius),dy=my-(y+radius);
        if(Math.sqrt(dx*dx+dy*dy)<=radius){draggingWheel=true;updateWheel(mx,my);return true;}
        return false;
    }
    public void onMouseRelease(int btn){if(btn==0){draggingWheel=false;draggingSlider=false;}}
    public void onMouseMove(double mx,double my){if(draggingWheel)updateWheel(mx,my);if(draggingSlider)updateBrightness(mx);}

    private void updateWheel(double mx,double my){
        int cx=x+radius,cy=y+radius; double dx=mx-cx,dy=my-cy,dist=Math.sqrt(dx*dx+dy*dy);
        hue=(float)(Math.atan2(dy,dx)/(Math.PI*2.0)); if(hue<0)hue+=1f;
        saturation=(float)Math.min(1.0,dist/radius);
        painter.setHSB(hue,saturation,brightness);
    }
    private void updateBrightness(double mx){
        brightness=(float)Math.max(0.0,Math.min(1.0,(mx-x)/(radius*2)));
        painter.setHSB(hue,saturation,brightness);
    }
    public int getTotalHeight(){return radius*2+SLIDER_M+SLIDER_H+22;}
}
