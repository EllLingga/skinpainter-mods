package com.skinpainter.mixin;

import com.skinpainter.client.SkinPainterClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerEntityRenderer.class)
public class PlayerEntityRendererMixin {
    @Inject(method = "getSkin", at = @At("RETURN"), cancellable = true)
    private void skinPainter_getSkin(AbstractClientPlayerEntity player, CallbackInfoReturnable<Identifier> cir) {
        if (SkinPainterClient.textureManager == null) return;
        Identifier custom = SkinPainterClient.textureManager.getCustomTextureId(player.getUuid());
        if (custom != null) cir.setReturnValue(custom);
    }
}
