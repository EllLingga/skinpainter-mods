package com.skinpainter.mixin;

import com.skinpainter.client.SkinPainterClient;
import com.skinpainter.client.network.ClientNetworkHandler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mengontrol seluruh input mouse saat paint mode aktif.
 *
 *  LMB tekan  → mulai stroke (snapshot untuk undo)
 *  LMB tahan  → lanjut paint / erase
 *  LMB lepas  → commit stroke + kirim ke server
 *  RMB        → putar kamera
 *  Scroll     → ubah ukuran brush
 */
@Mixin(Mouse.class)
public class MouseMixin {

    @Shadow @Final private MinecraftClient client;
    @Shadow private double cursorDeltaX;
    @Shadow private double cursorDeltaY;

    @Inject(method = "onMouseButton", at = @At("HEAD"), cancellable = true)
    private void skinPainter_onMouseButton(long window, int button, int action, int mods, CallbackInfo ci) {
        if (!SkinPainterClient.isInPaintMode) return;

        double sf = client.getWindow().getScaleFactor();
        double mx = client.mouse.getX() / sf;
        double my = client.mouse.getY() / sf;

        // RMB → kamera
        if (button == GLFW.GLFW_MOUSE_BUTTON_RIGHT) {
            SkinPainterClient.rightMouseHeld = (action == GLFW.GLFW_PRESS);
            ci.cancel();
            return;
        }

        // LMB → paint / erase / HUD
        if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            if (action == GLFW.GLFW_PRESS) {
                boolean consumed = SkinPainterClient.editorHud.onMouseClick(mx, my, button);
                if (!consumed) {
                    // Klik di dunia 3D → mulai stroke
                    SkinPainterClient.isPainting = true;
                    SkinPainterClient.skinPainter.onStrokeBegin(mx, my);
                }
            } else if (action == GLFW.GLFW_RELEASE) {
                if (SkinPainterClient.isPainting) {
                    SkinPainterClient.isPainting = false;
                    // Commit snapshot ke undo stack
                    SkinPainterClient.skinPainter.onStrokeEnd();
                    // Kirim skin ke server
                    if (client.player != null) {
                        ClientNetworkHandler.sendSkinUpdate(client.player.getUuid());
                    }
                }
                SkinPainterClient.editorHud.onMouseRelease(mx, my, button);
            }
            ci.cancel();
            return;
        }

        ci.cancel();
    }

    @Inject(method = "updateMouse", at = @At("HEAD"), cancellable = true)
    private void skinPainter_updateMouse(CallbackInfo ci) {
        if (!SkinPainterClient.isInPaintMode) return;
        if (!SkinPainterClient.rightMouseHeld) {
            cursorDeltaX = 0;
            cursorDeltaY = 0;
            ci.cancel();
        }
        // Jika RMB ditahan → biarkan Minecraft rotate kamera seperti biasa
    }

    @Inject(method = "onCursorPos", at = @At("TAIL"))
    private void skinPainter_onCursorPos(long window, double x, double y, CallbackInfo ci) {
        if (!SkinPainterClient.isInPaintMode) return;

        double sf = client.getWindow().getScaleFactor();
        double mx = x / sf;
        double my = y / sf;

        SkinPainterClient.editorHud.onMouseMove(mx, my);

        if (SkinPainterClient.isPainting) {
            SkinPainterClient.skinPainter.onStrokeDrag(mx, my);
        }
    }

    @Inject(method = "onMouseScroll", at = @At("HEAD"), cancellable = true)
    private void skinPainter_onScroll(long window, double h, double v, CallbackInfo ci) {
        if (!SkinPainterClient.isInPaintMode) return;
        int delta = v > 0 ? 1 : -1;
        SkinPainterClient.skinPainter.setBrushRadius(
                SkinPainterClient.skinPainter.getBrushRadius() + delta);
        ci.cancel();
    }
}
