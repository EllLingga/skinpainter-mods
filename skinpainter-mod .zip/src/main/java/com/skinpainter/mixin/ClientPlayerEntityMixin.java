package com.skinpainter.mixin;

import com.skinpainter.client.SkinPainterClient;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public class ClientPlayerEntityMixin {
    @Inject(method = "tickMovement", at = @At("HEAD"))
    private void skinPainter_lockMovement(CallbackInfo ci) {
        if (!SkinPainterClient.isInPaintMode) return;
        ClientPlayerEntity self = (ClientPlayerEntity)(Object) this;
        self.setVelocity(0, self.getVelocity().y, 0);
        self.input.movementForward  = 0;
        self.input.movementSideways = 0;
        self.input.jumping          = false;
        self.input.sneaking         = false;
        self.input.sprinting        = false;
    }
}
